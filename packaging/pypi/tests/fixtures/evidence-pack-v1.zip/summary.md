# Celmis — dependency evidence pack

Generated 2026-08-30T09:04:12+00:00
Audit run `run-fixture-0001`, started 2026-08-30T09:00:00Z

## What this is

The inventory of every dependency in the repositories below, the vulnerabilities known against them at the time of this run, and a hash of each file so the pack can be verified without trusting the tool that produced it.

It is evidence, not a compliance certificate. Whether it satisfies a particular obligation is a judgement this tool does not make.

## Scope

- Repositories: 2
- SBOM documents: 2 (CycloneDX 1.5)
- Findings: 3

## Findings by severity

- critical: 1
- high: 1
- low: 1

## Findings with no fixed version

1 of 3 have no upstream fix at the time of this run. These are the ones a filing usually has to explain rather than resolve.

## Repositories

- acme/gateway
- acme/payments

## Verifying this pack

`MANIFEST.json` lists a sha256 for every other file. Recompute them and compare; any mismatch means the pack was altered after it was generated.
